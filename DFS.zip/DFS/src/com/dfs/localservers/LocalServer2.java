package com.dfs.localservers;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class LocalServer2 {
	ServerSocket serverSocket;
	Socket socket, socket2;
	DataInputStream dataInputStream, dataInputStream2;
	DataOutputStream dataOutputStream, dataOutputStream2;
	Map<String, Object> chunkDetails = new HashMap<String, Object>();

	public void createLocalServer() {
		try {
	/*
	 * creating local server
	 * local server is listening to specific port
	 */
			serverSocket = new ServerSocket(939);

		} catch (Exception e) {
			
			//handling exception if any
			System.out.println(e.getMessage());
		}

	}

	public void connectToClientServer() {
		try {
			socket = serverSocket.accept();
		} catch (Exception e) {
			//handling exception if any

			System.out.println(e.getMessage());
		}
	}

	public void readRequestOrInformation() {
		try {
			//reading request from client
			dataInputStream = new DataInputStream(socket.getInputStream());
			String read_requested_data = dataInputStream.readUTF();
			if(read_requested_data.equals("fileA"));
			{
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void sendRequestOrResponce() {
		try {
			//sending responce to client
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
		dataOutputStream.writeUTF("C:\\Users\\akhil\\Desktop\\dfs files\\output\\final.txt");
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}

	/*
	 * this functionality is used to 
	 * connect to central server
	 */
	public void connectToMainServer() {
		try {
			//connecting local server to central server
			socket2 = new Socket("192.168.1.3", 174, serverSocket.getInetAddress(), 188);
			System.out.println("Connecting to Local server." + socket2.getLocalPort() + "\n Listening to Local server port"
					+ serverSocket.getLocalPort());
			System.out.println("Connecting to main server." + socket2.getRemoteSocketAddress());
		
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
	}
	/*
	 * this functionality is used to 
	 * send chunck information to central server
	 */

	public void sendServerInformationToMainServer() {
		try {
			
			dataOutputStream2 = new DataOutputStream(socket2.getOutputStream());
			dataOutputStream2.writeUTF(chunkDetails.toString());
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}

	//this functionality is used to reading responce from central server
	public void readInformationFromMainServer() {
		try {
			dataInputStream2 = new DataInputStream(socket2.getInputStream());
			String read_from_ms = dataInputStream2.readUTF();

		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
//this functionality is used to merge chunck files
/*
 * 	the method with arguments "mergeFiles(File[] files, File into)"
 * the first parameter takes list of chunck files and  second parameter "File into" is the path
 * to merge all chuncks 
 */
	public void mergeFiles(File[] files, File into) throws IOException {
		try (FileOutputStream fos = new FileOutputStream(into);
				BufferedOutputStream mergingStream = new BufferedOutputStream(fos)) {
			for (File f : files) {
				Files.copy(f.toPath(), mergingStream);

			}
		}
	}
//this functionality is used to getting the chuncnks from a specified path
	public void getChunks() {
		File folder = new File("C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerB");
//iterating the chunck files
		File[] fileChunkFolders = folder.listFiles();
		for (File chunkFolder : fileChunkFolders) {
			if (chunkFolder.isDirectory()) {
				List<String> chunkNames = new ArrayList<String>();
				for (File file : chunkFolder.listFiles()) {
					if (chunkFolder.isDirectory()) {
						chunkNames.add(file.getName());
					}
				}
				//storing all chunck files in a map
				chunkDetails.put(chunkFolder.getName(), chunkNames);
			}
		}
		System.out.println(chunkDetails.toString());
	}

	public void leaveInformationSendingToCS() {
		try {
			dataOutputStream2 = new DataOutputStream(socket2.getOutputStream());
			dataOutputStream2.writeUTF("Leaving");
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
	
	public void searchChunks()
	{
		
	}
	public static void main(String[] args) throws IOException {
		LocalServer2 objServerCode = new LocalServer2();
		objServerCode.createLocalServer();
		 objServerCode.connectToMainServer();
		 objServerCode.getChunks();
		 objServerCode.sendServerInformationToMainServer();

			objServerCode.connectToClientServer();
			objServerCode.sendRequestOrResponce();;
		 File folder = new File("C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerB\\FileA");
		 objServerCode.mergeFiles(folder.listFiles(), new File("C:\\Users\\akhil\\Desktop\\dfs files\\results.txt"));
		 
	}
}