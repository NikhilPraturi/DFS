package com.dfs.localservers;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class LocalServer1 {
	int bb=175;
	ServerSocket serverSocket;
	Socket socket, socket2,socket3;
	DataInputStream dataInputStream, dataInputStream2,dataInputStream3;
	DataOutputStream dataOutputStream, dataOutputStream2,dataOutputStream3;
	Map<String, Object> chunkDetails = new HashMap<String, Object>();
	String read_requested_data;
static File res=	new File("C:\\Users\\akhil\\Desktop\\dfs files\\output\\res.txt");
static File res2=	new File("C:\\Users\\akhil\\Desktop\\dfs files\\output\\res2.txt");

	public void createLocalServer() {
		try {
	/*
	 * creating local server
	 * local server is listening to specific port
	 */
			serverSocket = new ServerSocket(564);

		} catch (Exception e) {
			
			//handling exception if any
			System.out.println(e.getMessage());
		}

	}

	public void connectToClientServer() {
		try {
			//accepting client request
			socket = serverSocket.accept();
			
		} catch (Exception e) {
			//handling exception if any

			System.out.println(e.getMessage());
		}
	}

	public void readRequestOrInformation() {
		try {
			//reading request from client
			dataInputStream = new DataInputStream(socket.getInputStream());
			read_requested_data = dataInputStream.readUTF();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void sendRequestOrResponce() {
		try {
			//sending responce to client
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
	
		dataOutputStream.writeUTF(fromlocalserver);
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}

	/*
	 * this functionality is used to 
	 * connect to central server
	 */
	public void connectToMainServer() {
		try {
			//connecting local server to central server
			socket2 = new Socket("192.168.1.3", 174, serverSocket.getInetAddress(), bb);
			System.out.println("Connecting to Local server." + socket2.getLocalPort() + "\n Listening to Local server port"
					+ serverSocket.getLocalPort());
			System.out.println("Connecting to main server." + socket2.getRemoteSocketAddress());
		
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
	}
	/*
	 * this functionality is used to 
	 * send chunck information to central server
	 */

	public void sendServerInformationToMainServer() {
		try {
			
			dataOutputStream2 = new DataOutputStream(socket2.getOutputStream());
			dataOutputStream2.writeUTF(chunkDetails.toString());
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
String fromlocalserver=null;
	//this functionality is used to reading responce from central server
int cc=0;

	public void readInformationFromMainServer() {
		try {
			
			dataInputStream2 = new DataInputStream(socket2.getInputStream());
			String read_from_ms = dataInputStream2.readUTF();
			if(read_from_ms!=null)
			{
				int a=Integer.parseInt(read_from_ms);
				if(a!=bb) {
				
				socket3=new Socket("192.168.1.3", a);
				dataInputStream3=new DataInputStream(socket3.getInputStream());
				fromlocalserver=dataInputStream3.readUTF();
				System.out.println(fromlocalserver);
			File ff=new File(fromlocalserver);
		mergeFiles(ff.listFiles(),res );
				
				}
			}
		


		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
//this functionality is used to merge chunck files
/*
 * 	the method with arguments "mergeFiles(File[] files, File into)"
 * the first parameter takes list of chunck files and  second parameter "File into" is the path
 * to merge all chuncks 
 */
	public void mergeFiles(File[] files, File into) throws IOException {
		try (FileOutputStream fos = new FileOutputStream(into);
				BufferedOutputStream mergingStream = new BufferedOutputStream(fos)) {
			for (File f : files) {
				Files.copy(f.toPath(), mergingStream);

			}
		}
	}
//this functionality is used to getting the chuncnks from a specified path
	public void getChunks() {
		File folder = new File("C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerA");
//iterating the chunck files
		File[] fileChunkFolders = folder.listFiles();
		for (File chunkFolder : fileChunkFolders) {
			if (chunkFolder.isDirectory()) {
				List<String> chunkNames = new ArrayList<String>();
				for (File file : chunkFolder.listFiles()) {
					if (chunkFolder.isDirectory()) {
						chunkNames.add(file.getName());
					}
				}
				//storing all chunck files in a map
				chunkDetails.put(chunkFolder.getName(), chunkNames);
			}
		}
		System.out.println(chunkDetails.toString());
	}

	public void leaveInformationSendingToCS() {
		try {
			dataOutputStream2 = new DataOutputStream(socket2.getOutputStream());
			dataOutputStream2.writeUTF("Leaving");
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
	public void searchChunksInCS()
	{
if(read_requested_data.equals("filea")) {
try {
	dataOutputStream2 = new DataOutputStream(socket2.getOutputStream());
		dataOutputStream2.writeUTF("chuncks");
}
catch (Exception e) {

System.out.println(e.getMessage());
}
}
	}
	public void wholeMerge() {
		try {
		File ff=new File("C:\\Users\\akhil\\Desktop\\dfs files\\output");
		mergeFiles(ff.listFiles(), new File("C:\\Users\\akhil\\Desktop\\dfs files\\output\\final.txt"));
		}
		catch (Exception e) {
		
		System.out.println(e.getMessage());
		}
		}
	public static void main(String[] args) throws IOException {
		LocalServer1 objServerCode = new LocalServer1();
		objServerCode.createLocalServer();
		 objServerCode.connectToMainServer();
		 objServerCode.getChunks();
		 objServerCode.sendServerInformationToMainServer();

			objServerCode.connectToClientServer();
			objServerCode.readRequestOrInformation();
			objServerCode.searchChunksInCS();
objServerCode.readInformationFromMainServer();
			File folder = new File("C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerA\\FileA");
		 objServerCode.mergeFiles(folder.listFiles(),res2);
		objServerCode.wholeMerge();
		 objServerCode. sendRequestOrResponce();
	}
}