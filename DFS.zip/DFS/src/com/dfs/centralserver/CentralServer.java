package com.dfs.centralserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

public class CentralServer {
	
	/*
	 * creating instance of the json object
	 *  for reading key value pair from string
	 */
	JSONObject jsonObject = null;
	/*
	 * creaing a map instance
	 * for storing chunk data
	 */
	HashMap<String, Object> global_file_distribution_list = new HashMap<>();

	ServerSocket ss;
	Socket s;
	DataInputStream dis;
	DataOutputStream dos;
	int serverCount = 0;

	ArrayList<String> list_of_servers = new ArrayList<>();

	//this functionality is used to creating a central server
	
	
	public void createCentralServer() {
		try {
			//central server is listening to specific port number
			ss = new ServerSocket(174);
			System.out.println("main server started");
			list_of_servers.clear();
			while (true) {
			/*
			 * making server in infinite loop so that it can 
			 * accept multiple local servers connection
			 */
				s = ss.accept();//accepting the local server connection
				if (s != null) {//checking if local server is connected or not
					String local_server = s.getRemoteSocketAddress().toString().split("/")[1].toString();
					
					System.out.println(local_server);
				//	System.out.println(list_of_servers.isEmpty() + " -->" + list_of_servers.contains(local_server));
					//checking condition weather local server exist or not 
					if (list_of_servers.isEmpty() || !list_of_servers.contains(local_server)) {
						
						/*
						 * if not storing into list
						 */
						list_of_servers.add(local_server);//storing the newly created server 
/*
 * a method call "chunkOfLocalServers()"
 * is used to read the chunck files from a 
 * local server and storing in to a variable 
 */
						chunkOfLocalServers();
					}
				}
				sendChuncksInfoToRequestedServer();

			}
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}
/*
 * this functionality used 
 * to read the chunks from local servers
 */
	public void chunkOfLocalServers() {
		try {
//instantiating an inputstream
			dis = new DataInputStream(s.getInputStream());
			//reading local server request

			String server_data = dis.readUTF();
/*
 * a method call with arguments "chunckInf(server_data, s.getRemoteSocketAddress().toString().split("/")[1])";
 *sending list of chunks in a string and local server address as a parameter 
 */
			chunckInf(server_data, s.getRemoteSocketAddress().toString().split("/")[1]);
			System.out.println(global_file_distribution_list);//printing weather chunks are stored or not
		
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}

	}

	public void sendInformationToLocalServers() {
//sending the status of the connection to local servers
		try {
			InetAddress in = InetAddress.getLocalHost();

			dos = new DataOutputStream(s.getOutputStream());
			dos.writeUTF("server connected:" + in.getHostAddress() + ":" + in.getHostName());
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}

	/*
	 * this functionality is used to 
	 * map the chunck files to their local servers
	 */
	public void chunckInf(String chunkList, String lsAddressAndPort) {
		try {
			//converting a string to json 
			JSONObject js = new JSONObject(chunkList);
			//iterating the keys from a json
			Iterator i = js.keys();
			HashMap<String, Object> ls = new HashMap<>();
			while (i.hasNext()) {
				//storing each key in a variable
				String key = i.next().toString();
				//checking if weather key is getting or not 
				System.out.println(js.getJSONArray(key));
				//iterating values based on key
				JSONArray chunkJS = js.getJSONArray(key);
				Map<String, String> chunk_data = new HashMap<String, String>();
				for (int j = 0; j < chunkJS.length(); j++) {
			/*mapping each chunck data in
			 *  the form of key value pair
			 */
				
					chunk_data.put(chunkJS.getString(j), lsAddressAndPort);
				}
				//mapping key and hashmap object
				ls.put(key, chunk_data);
			}
//merging chuncks 
			if (serverCount > 0) {
				System.out.println("second");
				Iterator keys = ls.keySet().iterator();

				while (keys.hasNext()) {
					String key = keys.next().toString();
					Map<String, String> mpv = new HashMap<String, String>();
					mpv = (HashMap<String, String>) global_file_distribution_list.get(key);
					global_file_distribution_list.remove(key);
					mpv.putAll((HashMap<String, String>) ls.get(key));
					global_file_distribution_list.put(key, mpv);
				}
			} else {
				System.out.println("first");
				global_file_distribution_list.putAll(ls);
				serverCount+=1;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void removeLocalServer() throws IOException {
		// TODO Auto-generated method stub
		String server_data = dis.readUTF();
		if(server_data.equals("Leaving")) {
			String addressAndPort = s.getRemoteSocketAddress().toString().split("/")[1];
			
		}
		System.out.println(global_file_distribution_list.toString());
	}
	
	public void sendLocalServerInfo() throws IOException {
		// TODO Auto-generated method stub
		String server_data = dis.readUTF();
		if(server_data.equals("Leaving")) {
			String addressAndPort = s.getRemoteSocketAddress().toString().split("/")[1];
			
		}
		System.out.println(global_file_distribution_list.toString());
	}
public void sendChuncksInfoToRequestedServer()
{
	if(serverCount>0)
	{
		try {
		System.out.println("\\\\\\"+s.getPort());
		dos = new DataOutputStream(s.getOutputStream());
		dos.writeUTF(String.valueOf(939));
		}
		catch (Exception e) {

		System.out.println(e.getMessage());
		}
	}
}
	public static void main(String[] args) {
		CentralServer mainServer = new CentralServer();
		mainServer.createCentralServer();
//		mainServer.chunkOfLocalServers();

	}
}
