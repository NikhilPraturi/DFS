package com.dfs.client;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ClientCode {
	
	
		Socket s;
	    DataInputStream din;
	    DataOutputStream dout;
	public void createClient()
	{
		try 
		{
	    s=new Socket("192.168.1.3",564);
		
		}
		catch (Exception e) {
		
		System.out.println(e.getMessage());
		}
	    
	}

	public void searchForServers()
	{
		if(s!=null) 
		{
			try {
		din=new DataInputStream(s.getInputStream());
		String server_address=din.readUTF();
		System.out.println(server_address);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
		
		}
	}

		public void sendFileRequest()
		{
			
			System.out.println("enter file request");
			Scanner sc=new Scanner(System.in);
			String request=sc.next();
			try {
			dout=new DataOutputStream(s.getOutputStream());
			dout.writeUTF(request);
			}
			catch (Exception e) {
			
			System.out.println(e.getMessage());
			}
		}
		public static void main(String[] args) {
			
			ClientCode cc=new ClientCode();
			cc.createClient();
			cc.sendFileRequest();

			cc.searchForServers();
		}
	}

