package filestorage;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileRepository {
	
		File file;
		//storing file 
		private String file_path="C:\\Users\\akhil\\Desktop\\dfs files\\a.txt";
		public void loadfile()
		{
			//creating a file
			file=new File(file_path);
		}
		/*
		 * this functionality helps to convert
		 *file to chunks
		 */
		
		public void convertToChunks()
		{
			try {
			int partCounter=0;
	        int sizeOfFiles = 1024;// 1KB
	        byte[] buffer = new byte[sizeOfFiles];
	        FileInputStream fileInputStream=new FileInputStream(file);
	        BufferedInputStream bufferedInputStream=new BufferedInputStream(fileInputStream);
	        int bytes=0;

	    	int count=0;
	    	boolean serverFlag = true;
	        //till file length is not zero this is going to iterate 
	    	while ((bytes = bufferedInputStream.read(buffer)) > 0) 
	        {
	      
	        	String changeble_path=null;
	            //write each chunk of data into separate file with different number in name
	            String filePartName = String.format("%s.%03d", file.getName(), partCounter++);
	            if((count != 0 || count != 1) && count%2 == 0)
	            	serverFlag = false;
	            else
	            	serverFlag = true;
	           //storing the chunks in a folder till count 6
	            if(partCounter <= 6)
	            {
	            	changeble_path="C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerA\\FileA";
	            }
	            //if count is greater storing it into a seperate folder
	            else
	            {
	            	changeble_path="C:\\Users\\akhil\\Desktop\\dfs files\\LocalServerB\\FileA";
	            }
	            //creating a new chunck file 
	            File newFile = new File(changeble_path, filePartName);
	            
	            ///writing data into it
	            FileOutputStream out = new FileOutputStream(newFile) ;
	                out.write(buffer, 0, bytes);
	          
	        count++;
	        }
			}
			catch (Exception e) {
			
			System.out.println(e.getMessage());
			}
			
		}
		public static void main(String[] args) {
			//creating instance of a class
			FileRepository fr=new FileRepository();
			//method call to load file
		fr.loadfile();
		//method call to create chunks
			fr.convertToChunks();
		}
		
	}

